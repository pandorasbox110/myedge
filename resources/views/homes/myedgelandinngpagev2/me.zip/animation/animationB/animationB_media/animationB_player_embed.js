var oeTags = '<img src="animationB_media/animationB.gif" width="400" height="250" alt=""/>';         
document.write( oeTags );
