var oeTags = '<img src="animationC_media/animationC.gif" width="400" height="250" alt=""/>';         
document.write( oeTags );
