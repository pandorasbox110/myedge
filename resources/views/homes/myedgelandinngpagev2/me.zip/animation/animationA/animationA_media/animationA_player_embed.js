var oeTags = '<img src="animationA_media/animationA.gif" width="400" height="250" alt=""/>';         
document.write( oeTags );
