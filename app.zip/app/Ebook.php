<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Ebook extends Model
{
   
   	protected $primaryKey = 'id';
    public $timestamps = false;
    protected $guarded = [];

    protected $appends = [
        'file_name',
        'offline_file_name',
    ];


    //for init auto complte label data-> your data want to show
    public function getFileNameAttribute() {
        return basename($this->file);
    }

    public function getOfflineFileNameAttribute() {
        return basename($this->sample_file);
    }

    public function subject() {
      return $this->hasOne(Subject::class,'id','subject_id');
    }

    //get pebook for admin
    public static function paginatedSearch($keyword){
        
    
        $results = Ebook::with([
                                'subject'
                             ])
                      ->where(function($q) use($keyword) {
                            $q->where('ebook_title', 'LIKE', '%'.$keyword.'%')
                              ->orWhere('price','LIKE','%'.$keyword.'%');
                      })
                      ->where('is_deleted',0)
                      ->paginate(10);
        $results->appends([
            'keyword' => $keyword,
            'search_pagination' => 2
        ]);
        
        return $results;
    }

    //get my ebook
    public static function paginatedSearchMyEbook($keyword){

        $results = AsignedEbook::with([
                                    'ebook',
                                    'ebook.subject'
                                  ])
                            ->whereHas('ebook',function($q) use($keyword){
                                   $q->where('ebook_title', 'LIKE', '%'.$keyword.'%')
                                     ->orWhere('price','LIKE','%'.$keyword.'%')
                                     ->where('is_deleted',0);
                            })
                            ->where('user_id',Auth::user()->id)
                            ->where('is_deleted',0)
                            ->paginate(10);

        $results->appends([
            'keyword' => $keyword,
            'search_pagination' => 10,
        ]);
      
        return $results;
    }
}
