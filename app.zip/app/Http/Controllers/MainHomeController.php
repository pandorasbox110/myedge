<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\Institute;
use App\User;
use Storage;
use Config;
use DB;

class MainHomeController extends Controller
{

    public function index()
    {
        if(Auth::user()){
            // check user
            if(Auth::user()->userType->name == 'Admin'){

                return view('dashboards.home-admin');

            }elseif(Auth::user()->userType->name == 'Teacher' || Auth::user()->userType->name == 'Institute Admin'){

                return view('dashboards.home-teacher');

            }elseif (Auth::user()->userType->name == 'Student') {

                return view('dashboards.home-student');

            }else{

                return view('dashboards.home');

            }


        }else{//without login user
            
            return view('homes.home');
        }
    }
    
    public function uploadImage(Request $request){

        if (request('imageFile')) {
            
            $path3 = Storage::disk('public')->put('editor/images', request('imageFile'));
            $image='http://myedgetestsiteversion2.edupowerpublishing.com/storage/'.$path3;

            return response()->json($image);

        }else{
            return response()->json('error');
        }
    }

    public function uploadVideo(Request $request){

        if (request('videoFile')) {

            $file=request('videoFile')->storeAs('editor/videoaudio',request('videoFile')->getClientOriginalName(),'public');
            $path='http://myedgetestsiteversion2.edupowerpublishing.com/storage/'.$file;
            

            return response()->json($path);

        }else{
            return response()->json('error');
        }
    }
    
    public function profile(){
        
        $profile=User::where('id',Auth::user()->id)->first();
        return view('dashboards.profile',compact('profile'));
    }

    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        //
    }

    public function show($id)
    {
        //
    }


    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }


    /*Add ons function*/

    //get institute
    public function getInstitute(){
        
        $currentuser=Auth::user();
        
        if($currentuser->userType->name == 'Institute Admin'){
            
            $results=Institute::where('id',$currentuser->institute_id)
                              ->where('is_deleted',0)
                              ->get();
            
        }else{
            
            $results=Institute::where('is_deleted',0)->get(); 
            
        }
        return response()->json($results);
    }
    
    public function getCreatedUser(){
        
        $currentuser=Auth::user();
        $results=User::where('added_by',$currentuser->id)->get();
        $result=count($results);
        $data=array((int)$currentuser->create_num_teacher, $result,$currentuser->userType->name);
        return response()->json($data);
    }
}
