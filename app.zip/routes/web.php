
<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Auth::routes();

//logout
Route::get('/logout', '\App\Http\Controllers\Auth\LoginController@logout');

/*MainHomeController*/
//login
Route::get('/', 'MainHomeController@index');
Route::get('/home', 'MainHomeController@index')->name('home');

//editor upload image
Route::post('/upload/image', 'MainHomeController@uploadImage');
//editor upload video or audio
Route::post('/upload/video', 'MainHomeController@uploadVideo');

//get institute
Route::get('/users/get-institute', 'MainHomeController@getInstitute');

//get created user
Route::get('/users/get/created/user', 'MainHomeController@getCreatedUser');

//Grades
Route::get('/get-grades', 'GradesController@getGrades');

/*Module here*/
//dashboard

/*users*/
//admin
Route::resource('/users/admins', 'AdminUsersController');
Route::get('/users/admins/edit/{id}', 'AdminUsersController@edit');
Route::post('/users/admins/delete', 'AdminUsersController@delete');

//institute
Route::resource('/users/institutes', 'InstitutionalAdminUsersController');
Route::get('/users/institutes/edit/{id}', 'InstitutionalAdminUsersController@edit');
Route::post('/users/institutes/delete', 'InstitutionalAdminUsersController@delete');
//teacher
Route::resource('/users/teachers', 'TeacherUsersController');
Route::get('/users/teachers/edit/{id}', 'TeacherUsersController@edit');
Route::post('/users/teachers/delete', 'TeacherUsersController@delete');
//student
Route::resource('/users/students', 'StudentUsersController');
Route::get('/users/students/edit/{id}', 'StudentUsersController@edit');
Route::post('/users/students/delete', 'StudentUsersController@delete');

/*subject*/
Route::resource('/subjects', 'SubjectsController');
Route::post('/subjects/editor', 'SubjectsController@editor');
Route::get('/get-subjects', 'SubjectsController@getSubjects');
Route::post('/subjects/assigned', 'SubjectsController@getAssignedSubjects');
Route::get('/subjects/get/mysubjects', 'SubjectsController@getMySubjects');
Route::get('/subjects/assigned/teacher/{id}', 'SubjectsController@assignedSubjectTeacher');
Route::get('/subjects/assign/teacher/{id}', 'SubjectsController@assignSubjectTeacher');
Route::post('/subjects/assign/users/store', 'SubjectsController@assignSubject');
Route::post('/subjects/delete', 'SubjectsController@delete');
Route::get('/subjects/edit/{id}', 'SubjectsController@edit');

/*textbooks*/
//workbooks
Route::resource('/textbooks/workbooks', 'WorkBooksController');
Route::get('/textbooks/workbooks/{id}', 'WorkBooksController@show');
Route::get('/textbooks/workbooks/edit/{id}', 'WorkBooksController@edit');
Route::post('/textbooks/workbooks/delete', 'WorkBooksController@delete');
//techers guide
Route::resource('/textbooks/teachersguides', 'TeachersGuideController');
Route::get('/textbooks/teachersguides/{id}', 'TeachersGuideController@show');
//guides
Route::resource('/guides', 'GuidesController');
Route::get('/guides/view/{id}', 'GuidesController@show');
Route::get('/guides/edit/{id}', 'GuidesController@edit');
Route::post('/guides/delete', 'GuidesController@delete');
Route::get('/get-guides', 'GuidesController@getGuides');

//ebooks
Route::resource('/ebooks', 'EbooksController');
Route::get('/ebooks/get/myebooks', 'EbooksController@myEbook');
Route::get('/ebooks/get/products', 'EbooksController@EbookProduct');
Route::get('/ebooks/edit/{id}', 'EbooksController@edit');
Route::post('/ebooks/delete', 'EbooksController@delete');
Route::get('/ebooks/assigned/teacher/{id}', 'EbooksController@assignedEbookTeacher');
Route::get('/ebooks/assign/teacher/{id}', 'EbooksController@assignEbookTeacher');
Route::post('/ebooks/assign/users/store', 'EbooksController@assignEbook');
Route::post('/get/view/tg', 'EbooksController@getTG');
Route::post('/get/view/ebook', 'EbooksController@getSingleEbook');
Route::get('/trylang', 'EbooksController@trialOnly');

//address
Route::post('/getcities', 'ApiZipcodesController@selectCityWhereProvince');
Route::post('/getzipcodes', 'ApiZipcodesController@selectZipcodeWhereCity');

// //assigned product
// Route::post('/get-assigned-products','AssignedProductsController@getAssignedProducts');

/*TEACHER*/
//classes
Route::resource('/sections', 'SectionsController');
Route::get('/sections/view/{id}', 'SectionsController@show');
Route::get('/sections/edit/{id}', 'SectionsController@edit');
Route::post('/sections/delete/', 'SectionsController@delete');
Route::post('/sections/status', 'SectionsController@status');
Route::get('/sections/shared/{id}', 'SectionsController@shared');
Route::get('/sections/share/{id}', 'SectionsController@share');
Route::post('/sections/share/store', 'SectionsController@shareStore');
Route::post('/sections/share/delete', 'SectionsController@shareRemove');
//subject
Route::get('/sections/subjects/{id}', 'SectionsController@subjectIndex');//browse
Route::get('/sections/subjects/create/{id}', 'SectionsController@subjectCreate');//create
Route::post('/sections/subjects/store', 'SectionsController@subjectStore');//store
Route::get('/sections/subjects/edit/{section_id}/{id}', 'SectionsController@subjectEdit');
Route::post('/sections/subjects/delete/', 'SectionsController@subjectDelete');
Route::post('/sections/subjects/status', 'SectionsController@subjectStatus');
//lesson
Route::get('/sections/subjects/lessons/view/{section_id}/{subject_id}/{lessonid}','SectionsController@subjectLessons');//view
Route::post('/sections/subjects/lessons/store', 'SectionsController@subjectLessonStore');
Route::post('/sections/subjects/get-lesson', 'SectionsController@getSubjectLesson');
Route::post('/sections/subjects/lessons/delete', 'SectionsController@subjectLessonDelete');
Route::post('/sections/subjects/lessons/status', 'SectionsController@subjectLessonStatus');
//topic
Route::post('/sections/subjects/topic/store', 'SectionsController@lessonTopicStore');
Route::post('/sections/subjects/lessons/topic/view', 'SectionsController@lessonTopicView');
Route::post('/sections/subjects/lessons/topic/delete', 'SectionsController@lessonTopicDelete');
Route::post('/sections/subjects/lessons/topic/status', 'SectionsController@lessonTopicStatus');

//get my subject
Route::post('/sections/get-subject', 'SectionsController@getSubject');
//assessments
Route::get('/sections/subjects/assessments/{sectionid}/{subjectid}/{assessment_id}', 'SectionsController@subjectAssessmentIndex');
Route::get('/sections/subjects/assessments/students/{sectionid}/{subjectid}/{assessment_id}', 'SectionsController@subjectAssessmentIndexStudents');
Route::get('/sections/subjects/assessment/create/{sectionid}/{subjectid}','SectionsController@subjectAssessmentCreate');
Route::post('/get-sectiongradescale', 'SectionsController@getGradeScale');
Route::post('/sections/subjects/assessment/store', 'SectionsController@subjectAssessmentStore');
Route::post('/sections/subjects/assessment/get-assessement', 'SectionsController@subjectGetAssessment');
Route::post('/sections/subjects/assessment/delete', 'SectionsController@subjectAssessmentDelete');
Route::post('/sections/subjects/assessment/status', 'SectionsController@subjectAssessmentStatus');
Route::get('/sections/subjects/assessment/get-assessement/{sectionid}/{subjectid}/{id}','SectionsController@subjectGetAssessment2');
Route::get('/sections/subjects/assessment/answer/{sectionid}/{subjectid}/{id}','SectionsController@subjectAnswerAssessment');
Route::post('/sections/subjects/assessment/submit', 'SectionsController@subjectAssessmentSubmit');
Route::get('/sections/subjects/assessment/get/submitted/assessement/{sectionid}/{subjectid}/{id}','SectionsController@subjectGetSubmittedAssessment');
Route::get('/sections/subjects/assessment/view/submitted/assessement/{sectionid}/{subjectid}/{userid}/{id}','SectionsController@subjectViewSubmittedAssessment');
Route::post('/sections/subjects/assessment/grade', 'SectionsController@subjectAssessmentGrade');
//question
Route::get('/get-question-type', 'SectionsController@getQuestionType');
Route::post('/sections/subjects/assessment/question/store', 'SectionsController@assessmentQuestionStore');
Route::get('/sections/subjects/assessments/question-bank/{sectionid}/{subjectid}/{assessmentid}/{userid}', 'SectionsController@getQuestionBank');
Route::post('/sections/subjects/assessments/question-bank/store', 'SectionsController@assessmentQuestionBankStore');
Route::post('/sections/subjects/assessment/question/delete', 'SectionsController@deleteQuestion');
Route::post('/sections/subjects/assessment/question/get/question', 'SectionsController@getQuestion');

//assign assessment
Route::get('/sections/subjects/assessment/assigned/assessement/{sectionid}/{subjectid}/{assessmentid}', 'SectionsController@studentAssessment');
Route::get('/sections/subjects/assessment/assign/assessement/{sectionid}/{subjectid}/{assessmentid}', 'SectionsController@assignAssessment');
Route::post('/sections/subjects/assessment/assign/assessement/store', 'SectionsController@assignAssessmentStore');
//student
Route::get('/sections/students/{id}', 'SectionsController@studentIndex');
Route::get('/sections/students/create/{id}', 'SectionsController@studentCreate');
Route::post('/sections/students/store', 'SectionsController@studentsStore');
//records
Route::get('/sections/records/{id}', 'SectionsController@recordIndex');
Route::get('/sections/records/student/view/{id}', 'SectionsController@recordStudentView');
Route::get('/sections/records/student/view2/{sectionid}', 'SectionsController@recordStudentView2');
/*library*/
Route::resource('/libraries', 'LibrariesController');

/*My Account*/
Route::get('/profile', 'MainHomeController@profile');


/*MESSAGE*/
//chat
Route::resource('/chats', 'ChatsController');
//Route::get('/chats/index/{id}', 'ChatsController@index');
Route::get('search/users', 'ChatsController@searchUser');
Route::post('message/chat', 'ChatsController@sendMessage');

//forums and announcements
Route::resource('/forums', 'ForumsController');





