<h5>Subject Information</h5>
<input type="hidden" name="section_id" class="form-control geo-border-primary" value="{{$section->id ?? ''}}">
<input type="hidden" name="id" id="id" class="form-control geo-border-primary" value="{{$data->id ?? ''}}">
<div class="row">
    <div class="col-md-12">
        <div class="row pl-3 pr-3">
            <div class="col-md-6 p-1">
                <label>Subject Name</label>
                <input type="text" name="subject_name" id="subject-name" class="form-control geo-border-primary" required  placeholder="Enter Name" value="{{$data->mySubject->createdSubject->name ?? ''}}">
                <input type="hidden" name="subject_id" id="subject-id" class="form-control geo-border-primary" value="{{$data->mySubject->createdSubject->id ?? ''}}">
            </div>
        </div>
        <br>
        <div class="row pl-3 pr-3">
            <div class="col-md-6 p-1">
                <h5>Grade Scale</h5>
                <button type="button" class="btn btn-sm btn-success" onclick="addRow()"><span class="glyphicon glyphicon-plus-sign"></span> Add Row</button>&nbsp;
                <button type="button" class="btn btn-sm btn-danger" onclick="removeRow()"><span class="glyphicon glyphicon-remove-sign"></span> Del Row</button>&nbsp;
                <p>Please make sure that the total of your scale is 100</p>
                <table id="table-grade-scale" class="table table-bordered" style="margin-top: 15px;">
                    <tr>
                        <td width="5%"></td>
                        <th>Categories</th>
                        <th>Weight (%)</th>
                    </tr>
                </table>
            </div>
        </div>
    </div>
</div>  
<br>
<div class="right">
    <button class="btn geo-primary" value="{{$employee->id ?? ''}}" id="eid"><i class="fa fa-save"></i>&nbsp;&nbsp;Save</button>
    <button class="btn btn-danger" type="button" id="reset_btn"><i class="fa fa-eraser"></i>&nbsp;&nbsp;Reset</button>
</div>
<br><br>
<input type="hidden" name="current_user" id="current-user" class="form-control geo-border-primary" required value="{{Auth::user()->id ?? ''}}">

    