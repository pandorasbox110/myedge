<!DOCTYPE html>
<html>
    @section('styles')
    <link rel="stylesheet" type="text/css" href="/css/sidenav.css">
    @endsection
    @include('layouts.head', ['title' => 'CLASS'])
<body class="body-bg">
    @section('content')
        <div class="review-consult">
            <div class="container-reviews">
                @include('sections.navbar')
                <div class="tab-content" style="background-color: #f6f3ee !important; padding: 30px;">
                    <div id="admin-card" class="tab-pane fade show active">
                        <h5>Instruction</h5>
                        <br>
                        <form class="border geo-border-primary rounded p-3" id="add-instruction"> 
                            @csrf
                            <div class="row">
                                <div style="padding: 30px;">
                                    <h4>Step 1: Create/Select Subject</h4>
                                    <div style="padding-left: 20px;"> 
                                        <p style="font-size: 15px; font-weight: bold;color: green;"> * CREATE</p>
                                        - You can select subject that assigned to you or create your own subject
                                        <br>
                                        - Create a grade scale for your subject
                                        <br><br>
                                        <p style="font-size: 15px; font-weight: bold;color: green;"> * VIEW</p>
                                        - You can view subject by clicking the view icon beside subject name
                                        <br><br>
                                        <p style="font-size: 15px; font-weight: bold;color: green;"> * EDIT</p>
                                        - You can edit subject detailed by clicking the edit icon
                                        <br><br>
                                        <p style="font-size: 15px; font-weight: bold;color: green;"> * DELETE</p>
                                        - You can delete subject by clicking the red trash icon beside subject name
                                    </div>
                                    <br>
                                    <h4>Step 2: Enroll students</h4>
                                    <p style="padding: 20px;"> 
                                        - You can enroll student (Filtered by institute and grade) 
                                    </p>

                                    <h4>Step 3: You can now create Assessment and Assign To Student </h4>
                                    <p style="padding: 20px;"> 
                                        - go to subject click plus button and create asessment
                                        <br> 
                                        - Assign created assessmnet to student
                                    </p>

                                    <h4>Step 4: Report for this class is now available</h4>
                                    <p style="padding: 20px;"> 
                                        - general average of each student enrolled at your class
                                        <br>
                                        - click the eye button at the left side of student name to see the detailed grade of student 
                                        <br>
                                        - to see the student assessment the assessment button beside the student name 

                                     </p>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    @endsection
    
    @include('layouts.navbar', ['title' => 'CLASS- ' . $section->grade->name.' '. $section->name])
    @include('layouts.alert')
</body>
    <script type="text/javascript" src="/js/sections/navbar.js"></script>
    <script type="text/javascript" src="/js/alert.js"></script>
    <script type="text/javascript" src="/js/zipcode.js"></script>

</html>