<!DOCTYPE html>
<html>
    @section('styles')
    <link rel="stylesheet" type="text/css" href="/css/sidenav.css">
    <link rel="stylesheet" type="text/css" href="/css/font-awesome.min.css">
    @endsection
    @include('layouts.head', ['title' => 'CLASSES'])
    <body class="body-bg">
        @section('content')
        <h5 class ="headline">Browse</h5>
        <div class="row space-title">
            <div class="col-6">
                <form class="input-group" action="/sections" autocomplete="off">
                    <div class="input-group-prepend">
                        <button class="search-btn geo-primary" data-toggle="tooltip" title="Search">
                            <i class="fa fa-search"></i>
                        </button>
                         <input type="text" class="form-control mr-12" size="30" name="keyword" placeholder="Search Class Name or Grade" value="{{$keyword}}">
                    </div>
                </form>
                <br><br>
            </div>
            <div class="col-6">
                @if(Auth::user()->userType->name == 'Teacher' ||Auth::user()->userType->name == 'Institute Admin')
                    <a href="/sections/create" class="right geo-primary mb-1 button-add" data-toggle="tooltip" title="Add Subject">
                       New<i class="fa fa-plus"></i>
                    </a>
                @endif
            </div>
        </div>
        <div style="overflow: auto;" class="border">
            <table class="table text-center">
                <tr class="geo-secondary">
                    <th width="5%">S No.</th>
                    <th width="25%">Class Name</th>
                    <th width="20%">Grade</th>
                    <th width="15%">Start Date</th>
                    <th width="15%">End Date</th>
                    <th width="20%" class="text-center">Actions</th>
                </tr>
                
                @foreach($results as $key=> $result)
                    <tr>
                        <td>{{$key + 1}}</td>
                        <td>{{$result->name ?? ''}}</td>
                        <td>{{$result->grade->name ?? ''}}</td>
                        <td>{{$result->start_date ?? ''}}</td>
                        <td>{{$result->end_date ?? ''}}</td>
                        <td class="text-center">
                            
                            <!--for all-->
                            <a href="/sections/view/{{$result->id}}" data-toggle="tooltip" title="View Class" class="action-btn btn text-light mb-1 orange-pastel">
                                <i class="fa fa-eye"></i>
                            </a>
                            @if(Auth::user()->userType->name == 'Teacher' ||Auth::user()->userType->name == 'Institute Admin')
                                
                                @if(count($result->sectionTeacher) > 0)
                                    @if($result->sectionTeacher[0]->edit_priv == 1)
                                        <a href="/sections/edit/{{$result->id}}" data-toggle="tooltip" title="Edit Class" class="action-btn btn btn-primary text-light mb-1">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    @endif
                                    
                                    @if($result->sectionTeacher[0]->delete_priv == 1)
                                        <button type="button" value="{{$result->id}}" onclick="deleteData(this.value)" data-toggle="tooltip" title="Delete Class" class="action-btn btn btn-danger text-light delete-btn mb-1">
                                            <i class="fa fa-trash"></i>
                                        </button>
                                    @endif
                                    
                                    
                                @else
                                    <a href="/sections/edit/{{$result->id}}" data-toggle="tooltip" title="Edit Class" class="action-btn btn btn-primary text-light mb-1">
                                        <i class="fa fa-edit"></i>
                                    </a>
                                    
                                    <button type="button" value="{{$result->id}}" onclick="deleteData(this.value)" data-toggle="tooltip" title="Delete Class" class="action-btn btn btn-danger text-light delete-btn mb-1">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                    
                                    @if($result->status == 0)
                                    
                                        <button type="button" value="{{$result->id}}" onclick="uploadClass(this.value)" data-toggle="tooltip" title="Upload/Published this Class" class="action-btn btn purple-pastel text-light delete-btn mb-1">
                                            <i class="far fa-check-circle"></i>
                                        </button>
                                        
                                    @else
                                    
                                        <button type="button" value="{{$result->id}}" onclick="hideClass(this.value)" data-toggle="tooltip" title="Unpublished this Class" class="action-btn btn green-pastel text-light delete-btn mb-1">
                                            <i class="fas fa-check-circle"></i>
                                        </button>
                                    @endif
                                    
                                    <a href="/sections/shared/{{$result->id}}" data-toggle="tooltip" title="Share This Class" class="action-btn btn  text-light mb-1" style="background-color:#f39189;">
                                        <i class="fas fa-users-cog"></i>
                                    </a>
                                @endif
                            @endif
                        </td>
                    </tr>
                @endforeach
            </table>
        </div>
        <br>
        <div id="page-nav">{{ $results->links() }}</div>
        <br><br>
    @endsection
    
    @include('layouts.navbar', ['title' => 'MY CLASSES'])
    @include('layouts.alert')
    <script type="text/javascript" src="/js/alert.js"></script>
    <script type="text/javascript" src="/js/sections/index.js"></script>
    </body>
</html>