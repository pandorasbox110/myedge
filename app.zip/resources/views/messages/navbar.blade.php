<ul class="nav nav-pills">
    <li id="chat-li">
        <a class="nav-class" href="/chats">Chat</a>
    </li>
    <li id="email-li">
    	<a class="nav-class" href="/emails">Email</a>
    </li>
    <li id="forum-li">
    	<a class="nav-class" href="/forums">Forums and Announcement</a>
    </li>
</ul>
<input type="hidden" name="type" id="type" value="{{$type ?? ''}}">