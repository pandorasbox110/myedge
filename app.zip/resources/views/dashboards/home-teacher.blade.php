<!DOCTYPE html>
<html>
    @section('styles')
    <link rel="stylesheet" type="text/css" href="/css/sidenav.css">
    @endsection
    @include('layouts.head', ['title' => 'Home'])
<body class="body-bg">
    @section('content')
    <div class="col-md-12">
        <div class="row">
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12" style="display: inline-flex;">
                        <div class="col-md-6" style="background-color: #66cdaa; padding: 2px;height: 215px;">
                            <div class="col-md-12" style="display: inline-flex;">
                                <div class="col-md-4 sidenav-center">
                                    <img src="/images/icon/512.png" width="130%;">
                                </div>
                                <div class="col-md-7" style="color: white;">
                                    <h4 style="padding-top: 60px;">CLASSES</h4>
                                    <p style="color: white;">View Classes you are teaching</p>
                                </div>
                            </div>
                        </div>
                        &emsp;
                        <div class="col-md-6" style="background-color: #9575cd; padding: 2px;">
                            <div class="col-md-12" style="display: inline-flex;">
                                <div class="col-md-4 sidenav-center">
                                    <img src="/images/icon/text_A.png" width="130%;">
                                </div>
                                <div class="col-md-7" style="color: white;">
                                    <h4 style="padding-top: 60px;">LIBRARY</h4>
                                    <p style="color: white;">View teaching resources</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                &emsp;
                <div class="row">
                    <div class="col-md-12" style="display: inline-flex;">
                        <div class="col-md-6" style="background-color: #ff9955; padding: 2px;height: 215px;">
                            <div class="col-md-12" style="display: inline-flex;">
                                <div class="col-md-4 sidenav-center">
                                    <img src="/images/icon/file.png" width="130%;">
                                </div>
                                <div class="col-md-7" style="color: white;">
                                    <h4 style="padding-top: 60px;">EBOOK</h4>
                                    <p style="color: white;">Book you can read from anywhere</p>
                                </div>
                            </div>
                        </div>
                        &emsp;
                        <div class="col-md-6" style="background-color: #71cff3; padding: 2px;">
                            <div class="col-md-12" style="display: inline-flex;">
                                <div class="col-md-4 sidenav-center">
                                    <img src="/images/icon/puzzle.png" width="130%;">
                                </div>
                                <div class="col-md-7" style="color: white;">
                                    <h4 style="padding-top: 60px;">PRODUCTS</h4>
                                    <p style="color: white;">Books you can buy</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border geo-border-primary rounded" style="height: 45%">
                    <div style="background-color: #3e4e76">
                        <p style="font-size: 15px; padding:5px;color: white;">TO DO ASSESSMENTS</p>
                    </div>
                    <table class="table border" style="margin-top:-15px;">
                        <tr>
                            <td class="text-center">Assign Quiz1 to Kinder 2</td>
                        </tr>
                        <tr>
                            <td class="text-center">Assign Seatwork2 to Grade 1</td>
                        </tr>
                    </table>
                   
                </div>
                <br>
                <div class="border geo-border-primary rounded" style="height: 50%">
                    <div style="background-color: #3e4e76">
                        <p style="font-size: 15px; padding:5px;color: white;">COMPLETED ASSESSMENTS</p>
                    </div>
                    <table class="table border" style="margin-top:-15px;">
                        <tr>
                            <td class="text-center">Graded Erick Asuncion Assignment1</td>
                        </tr>
                        <tr>
                            <td class="text-center">Graded Benedict Santos Seatwork1</td>
                        </tr>
                        
                    </table>
                </div>
            </div>
            <div class="col-md-3">
                <div class="border geo-border-primary rounded" style="height: 100%">
                    <div style="background-color: #3e4e76">
                        <p style="font-size: 15px; padding:5px;color: white;">ANNOUNCEMENT</p>
                    </div>
                    <table class="table border" style="margin-top:-15px;">
                        <tr>
                            <td class="text-center">March 25-27, 2021 Monthly Exam</td>
                        </tr>
                        <tr>
                            <td class="text-center">April 26-28, 2021 Montly Exam</td>
                        </tr>
                        <tr>
                            <td class="text-center">May 24-26, 2021 1st Periodical Exam</td>
                        </tr>
                        <tr>
                            <td class="text-center">June 26,2021 Celebration of 85th Foundation Day</td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @endsection
    
    @include('layouts.navbar', ['title' => 'MYEDGE LEARNING'])
 
</body>
</html>