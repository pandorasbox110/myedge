<ul class="nav nav-pills">
    <li id="ebook-li">
        <a class="nav-class" href="/libraries">Question Bank</a>
    </li>
    <li id="product-li">
        <a class="nav-class" href="#" title="Under development">Media</a>
    </li>
</ul>
<input type="hidden" name="type" id="type" value="{{$type ?? ''}}">
