<ul class="nav nav-pills">
    <li id="ebook-li">
        <a class="nav-class" href="/ebooks/get/myebooks">My Ebook</a>
    </li>
    <li id="product-li">
        <a class="nav-class" href="/ebooks/get/products">Products</a>
    </li>
</ul>
<input type="hidden" name="type" id="type" value="{{$type ?? ''}}">
