@extends('auth.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-7" style="margin-top: 20px;">
            <h1 class="center" style="color: #dd5a43;">MyEDGE Learning</h1>
            <div class="card col-md-8 content-center" style="margin-top: 15px;">
                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf
                        <br>
                        <p style="font-size: 22px;color: #478fca;">Please Enter Your Information</p>
                        <hr>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus placeholder="Email address">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            <div class="col-md-12">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password" placeholder="Password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>
                        <br>
                        <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check row">
                                    <span style="margin-left: -130px;">
                                        <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                        &nbsp;&nbsp;&nbsp;&nbsp;
                                        <label class="form-check-label" for="remember">
                                            {{ __('Remember Me') }}
                                        </label>
                                    </span>
                                    <span style="margin-left: 104px;">
                                        <button type="submit" class="btn btn-outline-primary btn-lg" style="width: 70%;">{{ __('Login') }}</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="card-header content-center col-md-8" style="background-color: #5090c1;">
                <div class="row">
                    <div class="col-md-6">
                        @if (Route::has('password.request'))
                            <a class="btn btn-link" style="color: #f0d954 !important; font-size: 15px !important;" href="{{ route('password.request') }}">
                                {{ __('Forgot Your Password?') }}
                            </a>
                        @endif
                    </div>
                    <div class="col-md-6">
                        @if (Route::has('register'))
                            <a class="btn btn-link" href="{{ route('register') }}" style="color: #ccff77 !important; margin-left: 105px;font-size: 16px !important;">Sign Up</a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
