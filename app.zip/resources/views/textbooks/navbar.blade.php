<ul class="nav nav-pills">
    <li id="workbook-li">
        <a class="nav-class" href="/textbooks/workbooks">Curiculum Maps</a>
    </li>
    <li id="teacher-guide-li">
    	<a class="nav-class" href="/textbooks/teachersguides">Teachers Guides</a>
    </li>
</ul>
<input type="hidden" name="type" id="type" value="{{$type ?? ''}}">